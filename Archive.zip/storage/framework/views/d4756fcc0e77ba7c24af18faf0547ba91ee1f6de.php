<?php $__env->startSection('title', 'Post Edit'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
<h1>Edit Post</h1>
<?php if(session('success')): ?>
    <div class="alert-success">
       <p><?php echo e(session('success')); ?></p> 
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

  <form method="POST" action="<?php echo e(url('posts', $post->id )); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <input name="title" value="<?php echo e($post->title); ?>" type="text" placeholder="Angka 1"> 
    <input name="body" value="<?php echo e($post->body); ?>" type="text" placeholder="Angka 2">
    <button class="btn-blue">Submit</button>
  </form>
  </div>

<a href="<?php echo e(route('posts.index')); ?>"><button class="btn-green" style="margin-top:10px; width:100px;">Back</button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/geki/project/hashmicro/resources/views/post/edit.blade.php ENDPATH**/ ?>