<?php $__env->startSection('title', 'Semua Post'); ?>
 
<?php $__env->startSection('content'); ?>
<div class="wrapper">
<h1 style="text-align: center;">Simpel Crud</h1>

<?php if(session('success')): ?>
    <div class="alert-success">
       <p><?php echo e(session('success')); ?></p> 
    </div>
<?php endif; ?>
<a href="<?php echo e(route('posts.create')); ?>"><button class="btn-green" style="margin-bottom:10px; width:100px;">Create</button></a>
<table style="width:100%">
    <thead>
        <tr>
            <th>Angka 1</th>
            <th>Angka 2</th>
            <th>Result</th>
            <th>Nested Loop</th>
            <th colspan='2'></th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="width: 200px" >
              <!-- nested if -->
              <?php if($post->title): ?>
                <?php if($post->title =='21'): ?>
                   21 yes
                <?php else: ?>
                  <?php echo e($post->title); ?>

                <?php endif; ?>
              <?php else: ?>
               tidak ada
              <?php endif; ?>
             </td>
            <td  style="width: 200px" ><?php echo e($post->body); ?></td> 
            <!-- simple mathematic -->
            <td  style="width: 100px" ><?php echo e($post->title * $post->body); ?></td> 
            <td  style="width: 200px">
                <ol>
                    <?php $__currentLoopData = $post->type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($data->name); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </td> 
            <td style="width: 100px"><button class="btn-green"><a href="<?php echo e(route('posts.edit', $post->id)); ?>">Edit</a></button></td>
            <form method="POST" action="<?php echo e(url('posts', $post->id )); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
            <td style="width: 100px"><button class="btn-red">Hapus</button></td>
            </form>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/geki/project/hashmicro/resources/views/post/index.blade.php ENDPATH**/ ?>